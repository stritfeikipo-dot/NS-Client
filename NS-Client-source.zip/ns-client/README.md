# NS Client

Client-side Fabric PvP visuals mod for **Minecraft 1.21.11**, built for the Holyworld server.
No aimbot, no auto-attack, no combat automation — everything here is cosmetic/informational.

- Mod ID: `nsclient`
- Package: `com.nsclient`
- Build artifact: `NS-Client.jar`
- Theme: "Modern Purple" (dark/black/purple panels, neon purple accents)

## Features implemented

- **HUD**: FPS, CPS, ping, coordinates, keystrokes (WASD), watermark — all draggable,
  scalable (mouse wheel in the GUI) and color-configurable, position persisted.
- **Target HUD**: name + HP of whatever entity you're looking at.
- **Hitmarker**: cross / star / ring styles with a punch-scale + fade animation (duration
  and size configurable), not just a static flash.
- **Combo counter**: increments on repeated hits on the same entity within 2.5s, with a
  "punch" scale-up animation on every new hit.
- **Kill effects**: burst / ring / upward particle styles, configurable particle count.
- **Custom crosshair**: cross / dot / circle / T / X shapes (click "Shape: X >" in the
  GUI to cycle), adjustable size/thickness/color, optional hit-triggered pulse animation
  (strength + speed sliders); cancels the vanilla crosshair via a mixin.
- **Armor HUD** (durability %) and **potion effect HUD** (name, amplifier, time left).
- **ClickGUI**: rounded-corner "Modern Purple" cards, an eased slide-in on open, animated
  pill-shaped toggle switches, animated fade+slide reveal for each module's settings
  panel, sidebar with search + category tabs (HUD/COMBAT/RENDER/MISC), per-module
  toggle, expandable settings (sliders, colors, keybinds, cycleable shape/style rows),
  live HUD drag-and-drop + scroll-to-resize.
  (Per-module icons were intentionally skipped for now — flagged as lower priority.)
- **Config persistence**: `config/nsclient/config.json`, saved on GUI close, on
  disconnect, and on shutdown; loaded on launch.

## Building

This was written in a sandbox with **no network access**, so the Gradle build has not
been run here — the dependency versions below were checked against current Fabric/Modrinth
pages, but actually compiling against 1.21.11's real (obfuscated, Yarn-mapped) classes is
something only a real environment can confirm.

**On your machine / on GitHub Actions (`.github/workflows/build.yml` does this for you):**

```bash
gradle build
```

Output: `build/libs/NS-Client-1.0.0.jar` (plus a `-sources.jar`).

Dependency versions used (verified current for 1.21.11 at time of writing):

| Component    | Version              |
|--------------|-----------------------|
| Minecraft    | 1.21.11               |
| Fabric Loader| 0.18.4                |
| Yarn         | 1.21.11+build.4        |
| Fabric API   | 0.141.5+1.21.11        |
| Fabric Loom  | 1.14.4                 |
| Java         | 21                     |

## Honest status / what to verify first

I could not run this build myself (no network/Gradle execution in this environment), so
per your instructions I'm not presenting this as a verified-working jar. Push it to GitHub
and let `.github/workflows/build.yml` compile it — that's the real test. The spots most
likely to need a small fix on a brand-new version like 1.21.11:

1. **`InGameHud#renderCrosshair` signature** (mixin target) — method name/params may have
   shifted in 1.21.11's renderer rework.
2. **`StatusEffectInstance.getEffectType()`** — the registry-entry unwrap pattern
   (`.value().getName()`) matches recent versions but should be double-checked.
2. **`GameOptions` key field names** (`attackKey`, `useKey`, `forwardKey`, etc.) — Yarn
   occasionally renames these.
4. **`DrawContext.getMatrices()` transform calls** (push/translate/scale/pop) — Mojang has
   been reworking the renderer; if 1.21.11 changed this API shape, every HUD module's
   render method needs the same small adjustment.

If CI reports errors on any of these (or anything else), paste the log back and I'll fix
it directly — these are all narrow, mechanical fixes, not redesigns.

## Installing on Android (PojavLauncher / Zalith Launcher 2 / MJLauncher)

1. Install Fabric Loader 0.18.4+ for 1.21.11 through the launcher's version installer.
2. Drop `fabric-api-0.141.5+1.21.11.jar` and `NS-Client.jar` into `.minecraft/mods/`.
3. Launch, join Holyworld, press **Right Shift** to open the NS Client menu (rebindable
   per-module key capture is also available per-feature in the GUI).
