package com.nsclient.config;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.nsclient.module.Module;
import com.nsclient.module.ModuleManager;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Persists every module's enabled state, settings, HUD position/scale and keybind to config/nsclient/config.json. */
public class ConfigManager {
    private static final Path CONFIG_DIR = FabricLoader.getInstance().getConfigDir().resolve("nsclient");
    private static final Path CONFIG_FILE = CONFIG_DIR.resolve("config.json");

    public static void save(ModuleManager manager) {
        try {
            Files.createDirectories(CONFIG_DIR);
            JsonObject root = new JsonObject();
            JsonObject modulesObj = new JsonObject();
            for (Module m : manager.getModules()) {
                JsonObject obj = new JsonObject();
                m.writeConfig(obj);
                modulesObj.add(m.getName(), obj);
            }
            root.add("modules", modulesObj);

            try (Writer writer = Files.newBufferedWriter(CONFIG_FILE, StandardCharsets.UTF_8)) {
                new GsonBuilder().setPrettyPrinting().create().toJson(root, writer);
            }
        } catch (IOException e) {
            System.err.println("[NS Client] Failed to save config: " + e.getMessage());
        }
    }

    public static void load(ModuleManager manager) {
        if (!Files.exists(CONFIG_FILE)) return;
        try {
            String content = Files.readString(CONFIG_FILE, StandardCharsets.UTF_8);
            JsonObject root = JsonParser.parseString(content).getAsJsonObject();
            if (!root.has("modules")) return;
            JsonObject modulesObj = root.getAsJsonObject("modules");
            for (Module m : manager.getModules()) {
                if (modulesObj.has(m.getName())) {
                    m.readConfig(modulesObj.getAsJsonObject(m.getName()));
                }
            }
        } catch (IOException e) {
            System.err.println("[NS Client] Failed to load config: " + e.getMessage());
        } catch (RuntimeException e) {
            System.err.println("[NS Client] Failed to parse config: " + e.getMessage());
        }
    }
}
