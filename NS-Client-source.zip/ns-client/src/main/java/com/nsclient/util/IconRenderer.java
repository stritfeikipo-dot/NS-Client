package com.nsclient.util;

import net.minecraft.client.gui.DrawContext;

/**
 * Minimalist geometric glyphs for the sidebar nav (no texture atlas needed).
 * Each icon is drawn inside a size x size box at (x, y) with the given color.
 */
public final class IconRenderer {

    public enum Icon { VISUALS, HUD, MISC, THEMES, HUD_EDIT, SOCIALS, KEYBINDS, CONFIGS, SEARCH, CHEVRON, PLAYER, WORLD }

    private IconRenderer() {}

    public static void draw(DrawContext context, Icon icon, int x, int y, int size, int color) {
        switch (icon) {
            case VISUALS -> drawEye(context, x, y, size, color);
            case HUD -> drawMonitor(context, x, y, size, color);
            case MISC -> drawWrench(context, x, y, size, color);
            case THEMES -> drawPalette(context, x, y, size, color);
            case HUD_EDIT -> drawMonitor(context, x, y, size, color);
            case SOCIALS -> drawBubble(context, x, y, size, color);
            case KEYBINDS -> drawKeyboard(context, x, y, size, color);
            case CONFIGS -> drawFolder(context, x, y, size, color);
            case SEARCH -> drawMagnifier(context, x, y, size, color);
            case CHEVRON -> drawChevron(context, x, y, size, color);
            case PLAYER -> drawPerson(context, x, y, size, color);
            case WORLD -> drawGlobe(context, x, y, size, color);
        }
    }

    private static void drawEye(DrawContext context, int x, int y, int s, int c) {
        int midY = y + s / 2;
        context.fill(x, midY - 1, x + s, midY + 1, c);
        int pupil = Math.max(2, s / 3);
        context.fill(x + (s - pupil) / 2, midY - pupil / 2, x + (s - pupil) / 2 + pupil, midY + pupil / 2, c);
    }

    private static void drawMonitor(DrawContext context, int x, int y, int s, int c) {
        int h = (int) (s * 0.7);
        outline(context, x, y, s, h, c);
        context.fill(x + s / 2 - 1, y + h, x + s / 2 + 1, y + h + 2, c);
        context.fill(x + s / 4, y + h + 2, x + s - s / 4, y + h + 3, c);
    }

    private static void drawWrench(DrawContext context, int x, int y, int s, int c) {
        context.fill(x, y + s - 2, x + s - 2, y, c);
        context.fill(x, y, x + 3, y + 3, c);
        context.fill(x + s - 4, y + s - 3, x + s - 1, y + s, c);
    }

    private static void drawPalette(DrawContext context, int x, int y, int s, int c) {
        drawCircleFilled(context, x + s / 2, y + s / 2, s / 2, c);
        context.fill(x + s / 2 - 1, y + s / 2 - 1, x + s / 2 + 2, y + s / 2 + 2, 0xFF000000);
    }

    private static void drawBubble(DrawContext context, int x, int y, int s, int c) {
        int h = (int) (s * 0.75);
        context.fill(x, y, x + s, y + h, c);
        int[] xs = {x + 2, x + 6, x + 2};
        int[] ys = {y + h, y + h, y + h + 4};
        triangle(context, xs, ys, c);
    }

    private static void drawKeyboard(DrawContext context, int x, int y, int s, int c) {
        outline(context, x, y, s, (int) (s * 0.6), c);
        int keyW = Math.max(1, s / 5);
        for (int i = 0; i < 4; i++) {
            context.fill(x + 1 + i * (keyW + 1), y + 2, x + 1 + i * (keyW + 1) + keyW, y + 2 + keyW, c);
        }
    }

    private static void drawFolder(DrawContext context, int x, int y, int s, int c) {
        context.fill(x, y + s / 4, x + s, y + s, c);
        context.fill(x, y + s / 4 - 2, x + s / 2, y + s / 4, c);
    }

    private static void drawMagnifier(DrawContext context, int x, int y, int s, int c) {
        int r = s / 2 - 1;
        drawCircleOutline(context, x + r, y + r, r, c);
        context.fill(x + s - 2, y + s - 2, x + s, y + s, c);
    }

    private static void drawChevron(DrawContext context, int x, int y, int s, int c) {
        for (int i = 0; i < s / 2; i++) {
            context.fill(x + i, y + i, x + i + 1, y + i + 2, c);
            context.fill(x + i, y + s - i - 2, x + i + 1, y + s - i, c);
        }
    }

    private static void drawPerson(DrawContext context, int x, int y, int s, int c) {
        drawCircleFilled(context, x + s / 2, y + s / 4, s / 4, c);
        context.fill(x + s / 4, y + s / 2, x + s - s / 4, y + s, c);
    }

    private static void drawGlobe(DrawContext context, int x, int y, int s, int c) {
        drawCircleOutline(context, x + s / 2, y + s / 2, s / 2 - 1, c);
        context.fill(x, y + s / 2, x + s, y + s / 2 + 1, c);
    }

    private static void outline(DrawContext context, int x, int y, int w, int h, int c) {
        context.fill(x, y, x + w, y + 1, c);
        context.fill(x, y + h - 1, x + w, y + h, c);
        context.fill(x, y, x + 1, y + h, c);
        context.fill(x + w - 1, y, x + w, y + h, c);
    }

    private static void triangle(DrawContext context, int[] xs, int[] ys, int c) {
        int minX = Math.min(xs[0], Math.min(xs[1], xs[2]));
        int maxX = Math.max(xs[0], Math.max(xs[1], xs[2]));
        int minY = Math.min(ys[0], Math.min(ys[1], ys[2]));
        int maxY = Math.max(ys[0], Math.max(ys[1], ys[2]));
        context.fill(minX, minY, maxX + 1, maxY + 1, c);
    }

    private static void drawCircleFilled(DrawContext context, int cx, int cy, int r, int c) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy)));
            context.fill(cx - dx, cy + dy, cx + dx, cy + dy + 1, c);
        }
    }

    private static void drawCircleOutline(DrawContext context, int cx, int cy, int r, int c) {
        int segments = 16;
        for (int i = 0; i < segments; i++) {
            double a = 2 * Math.PI * i / segments;
            int x = cx + (int) (Math.cos(a) * r);
            int y = cy + (int) (Math.sin(a) * r);
            context.fill(x, y, x + 1, y + 1, c);
        }
    }
}
