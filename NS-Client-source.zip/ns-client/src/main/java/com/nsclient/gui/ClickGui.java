package com.nsclient.gui;

import com.nsclient.NSClientClient;
import com.nsclient.config.ConfigManager;
import com.nsclient.module.Category;
import com.nsclient.module.HudModule;
import com.nsclient.module.Module;
import com.nsclient.module.setting.BooleanSetting;
import com.nsclient.module.setting.ColorSetting;
import com.nsclient.module.setting.Setting;
import com.nsclient.module.setting.SliderSetting;
import com.nsclient.module.impl.CrosshairModule;
import com.nsclient.module.impl.HitmarkerModule;
import com.nsclient.module.impl.KillEffectsModule;
import com.nsclient.util.Animator;
import com.nsclient.util.UIRenderUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * NS Client ClickGUI - "Modern Purple" theme.
 * Rounded cards, an eased slide-in on open, animated toggle knobs and an animated
 * fade+slide reveal for each module's settings panel.
 */
public class ClickGui extends Screen {

    private static final int COL_BG = 0xE60C0712;
    private static final int COL_SIDEBAR = 0xFF140B1E;
    private static final int COL_PANEL = 0xFF1B1026;
    private static final int COL_PANEL_ALT = 0xFF221433;
    private static final int COL_ACCENT = 0xFFB388FF;
    private static final int COL_ACCENT_DIM = 0xFF6E3FCE;
    private static final int COL_TEXT = 0xFFEDE6F7;
    private static final int COL_TEXT_DIM = 0xFF9A8CB5;
    private static final int COL_OFF = 0xFF3A2E4A;

    private static final int CARD_RADIUS = 8;
    private static final int ROW_RADIUS = 5;

    private static final int SIDEBAR_W = 120;
    private static final int PANEL_X = 140;
    private static final int PANEL_Y = 40;
    private static final int PANEL_W = 260;
    private static final int ROW_H = 24;
    private static final int SETTING_SLIDER_H = 21;
    private static final int SETTING_BOOL_H = 16;
    private static final int SETTING_COLOR_H = 14;
    private static final int KEYBIND_ROW_H = 16;

    private final Animator anim = new Animator();
    private long openedAtNanos = -1;

    private Category selectedCategory = Category.HUD;
    private String search = "";
    private Module expanded = null;
    private Module bindingModule = null;
    private SliderSetting draggingSlider = null;
    private HudModule draggingHud = null;
    private double dragOffsetX, dragOffsetY;

    public ClickGui() {
        super(Text.literal("NS Client"));
    }

    @Override
    protected void init() {
        super.init();
        openedAtNanos = System.nanoTime();
    }

    private float openProgress() {
        if (openedAtNanos < 0) return 1f;
        float elapsed = (System.nanoTime() - openedAtNanos) / 1_000_000_000f;
        return UIRenderUtil.easeOutCubic(Math.min(1f, elapsed / 0.22f));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        anim.beginFrame();
        float t = openProgress();

        int bgAlpha = (int) (0xE6 * t);
        context.fill(0, 0, this.width, this.height, (bgAlpha << 24) | (COL_BG & 0xFFFFFF));

        renderLivePreview(context);

        context.getMatrices().push();
        context.getMatrices().translate((1 - t) * -36, 0, 0);
        renderSidebar(context, mouseX, mouseY, t);
        context.getMatrices().pop();

        context.getMatrices().push();
        context.getMatrices().translate(0, (1 - t) * -24, 0);
        renderModulePanel(context, mouseX, mouseY, t);
        context.getMatrices().pop();

        super.render(context, mouseX, mouseY, delta);
    }

    // ---------------------------------------------------------------- sidebar

    private void renderSidebar(DrawContext context, int mouseX, int mouseY, float globalAlpha) {
        UIRenderUtil.fillRounded(context, 10, 10, 10 + SIDEBAR_W, this.height - 10, CARD_RADIUS, withAlpha(COL_SIDEBAR, globalAlpha));
        context.drawTextWithShadow(this.textRenderer, "NS CLIENT", 20, 18, withAlpha(COL_ACCENT, globalAlpha));

        int searchY = 34;
        UIRenderUtil.fillRounded(context, 18, searchY, 10 + SIDEBAR_W - 8, searchY + 16, 4, withAlpha(COL_PANEL_ALT, globalAlpha));
        String shown = search.isEmpty() ? "Search..." : search;
        context.drawTextWithShadow(this.textRenderer, shown, 22, searchY + 4, withAlpha(search.isEmpty() ? COL_TEXT_DIM : COL_TEXT, globalAlpha));

        int y = 60;
        for (Category cat : Category.values()) {
            boolean selected = cat == selectedCategory;
            boolean hovered = isInside(mouseX, mouseY, 10, y, SIDEBAR_W, ROW_H);
            float hoverT = anim.animate("cat_hover_" + cat.name(), (selected || hovered) ? 1f : 0f, 12f);

            if (hoverT > 0.01f) {
                int bg = selected
                        ? UIRenderUtil.lerpArgb(0x00000000, COL_PANEL_ALT, hoverT)
                        : UIRenderUtil.lerpArgb(0x00000000, 0x33FFFFFF, hoverT);
                UIRenderUtil.fillRounded(context, 10, y, 10 + SIDEBAR_W, y + ROW_H, ROW_RADIUS, withAlpha(bg, globalAlpha));
            }
            if (selected) {
                context.fill(10, y + 4, 13, y + ROW_H - 4, withAlpha(COL_ACCENT, globalAlpha));
            }
            context.drawTextWithShadow(this.textRenderer, cat.name(), 20, y + 8,
                    withAlpha(UIRenderUtil.lerpArgb(COL_TEXT_DIM, COL_ACCENT, selected ? 1f : hoverT * 0.4f), globalAlpha));
            y += ROW_H + 2;
        }
    }

    // ---------------------------------------------------------------- module panel

    private List<Module> getVisibleModules() {
        List<Module> result = new ArrayList<>();
        for (Module m : NSClientClient.MODULES.getModules()) {
            if (m.getCategory() != selectedCategory) continue;
            if (!search.isEmpty() && !m.getDisplayName().toLowerCase().contains(search.toLowerCase())) continue;
            result.add(m);
        }
        return result;
    }

    private void renderModulePanel(DrawContext context, int mouseX, int mouseY, float globalAlpha) {
        UIRenderUtil.fillRounded(context, PANEL_X, PANEL_Y, PANEL_X + PANEL_W, this.height - 10, CARD_RADIUS, withAlpha(COL_PANEL, globalAlpha));

        int y = PANEL_Y + 8;
        for (Module m : getVisibleModules()) {
            boolean hovered = isInside(mouseX, mouseY, PANEL_X + 6, y, PANEL_W - 12, ROW_H);
            float hoverT = anim.animate("row_hover_" + m.getName(), hovered ? 1f : 0f, 14f);
            if (hoverT > 0.01f) {
                UIRenderUtil.fillRounded(context, PANEL_X + 6, y, PANEL_X + PANEL_W - 6, y + ROW_H, ROW_RADIUS,
                        withAlpha(UIRenderUtil.lerpArgb(0x00000000, COL_PANEL_ALT, hoverT), globalAlpha));
            }

            context.drawTextWithShadow(this.textRenderer, m.getDisplayName(), PANEL_X + 14, y + 8,
                    withAlpha(m.isEnabled() ? COL_TEXT : COL_TEXT_DIM, globalAlpha));

            float toggleT = anim.animate("toggle_" + m.getName(), m.isEnabled() ? 1f : 0f, 16f);
            drawToggle(context, PANEL_X + PANEL_W - 40, y + 5, toggleT, globalAlpha);

            y += ROW_H + 2;

            float expandT = anim.animate("expand_" + m.getName(), expanded == m ? 1f : 0f, 10f);
            if (expandT > 0.01f) {
                y = renderModuleSettings(context, m, y, expandT, globalAlpha);
            }
        }
    }

    private int renderModuleSettings(DrawContext context, Module m, int y, float revealT, float globalAlpha) {
        float alpha = revealT * globalAlpha;
        int slideY = (int) ((1 - revealT) * -6);

        context.fill(PANEL_X + 10, y + slideY, PANEL_X + PANEL_W - 10, y + 2 + slideY, withAlpha(COL_ACCENT_DIM, alpha));
        y += 6;

        for (Setting<?> setting : m.getSettings()) {
            if (setting instanceof SliderSetting slider) {
                context.drawTextWithShadow(this.textRenderer,
                        slider.getName() + ": " + String.format("%.2f", slider.getValue()),
                        PANEL_X + 14, y + slideY, withAlpha(COL_TEXT_DIM, alpha));
                y += 11;
                int barX = PANEL_X + 14;
                int barW = PANEL_W - 40;
                UIRenderUtil.fillRounded(context, barX, y + slideY, barX + barW, y + 4 + slideY, 2, withAlpha(COL_PANEL_ALT, alpha));
                double pct = (slider.getValue() - slider.getMin()) / (slider.getMax() - slider.getMin());
                int fillW = (int) (barW * clamp01(pct));
                if (fillW > 0) {
                    UIRenderUtil.fillRounded(context, barX, y + slideY, barX + fillW, y + 4 + slideY, 2, withAlpha(COL_ACCENT, alpha));
                }
                y += 10;
            } else if (setting instanceof ColorSetting color) {
                context.drawTextWithShadow(this.textRenderer, color.getName(), PANEL_X + 14, y + slideY, withAlpha(COL_TEXT_DIM, alpha));
                UIRenderUtil.fillRounded(context, PANEL_X + PANEL_W - 34, y - 2 + slideY, PANEL_X + PANEL_W - 14, y + 10 + slideY, 3,
                        withAlpha(color.getValue() | 0xFF000000, alpha));
                y += SETTING_COLOR_H;
            } else if (setting instanceof BooleanSetting bool) {
                float boolT = anim.animate("bool_" + m.getName() + "_" + bool.getName(), bool.getValue() ? 1f : 0f, 16f);
                drawToggle(context, PANEL_X + PANEL_W - 40, y + slideY, boolT, alpha);
                context.drawTextWithShadow(this.textRenderer, bool.getName(), PANEL_X + 14, y + 2 + slideY, withAlpha(COL_TEXT_DIM, alpha));
                y += SETTING_BOOL_H;
            }
        }

        String modeLabel = modeRowLabel(m);
        if (modeLabel != null) {
            context.drawTextWithShadow(this.textRenderer, modeLabel + "  >", PANEL_X + 14, y + slideY,
                    withAlpha(COL_ACCENT, alpha));
            y += SETTING_BOOL_H;
        }

        String bindLabel = bindingModule == m ? "Press a key..." : "Bind: " + keyName(m.getKeyCode());
        context.drawTextWithShadow(this.textRenderer, bindLabel, PANEL_X + 14, y + slideY,
                withAlpha(bindingModule == m ? COL_ACCENT : COL_TEXT_DIM, alpha));
        y += KEYBIND_ROW_H;

        return y + 6;
    }

    /** Returns the "Shape/Style: X" label for modules with a cycleable enum mode, or null if m has none. */
    private static String modeRowLabel(Module m) {
        if (m instanceof CrosshairModule ch) return "Shape: " + ch.getShape().name();
        if (m instanceof HitmarkerModule hm) return "Style: " + hm.getStyle().name();
        if (m instanceof KillEffectsModule ke) return "Style: " + ke.getStyle().name();
        return null;
    }

    /** Advances the enum mode for modules that have one (called when the mode row is clicked). */
    private static void cycleMode(Module m) {
        if (m instanceof CrosshairModule ch) ch.cycleShape();
        else if (m instanceof HitmarkerModule hm) hm.cycleStyle();
        else if (m instanceof KillEffectsModule ke) ke.cycleStyle();
    }

    private String keyName(int keyCode) {
        if (keyCode == -1) return "None";
        String name = GLFW.glfwGetKeyName(keyCode, 0);
        return name != null ? name.toUpperCase() : ("Key " + keyCode);
    }

    /** Animated pill-shaped toggle switch; progress 0..1 slides the knob and crossfades the track color. */
    private void drawToggle(DrawContext context, int x, int y, float progress, float globalAlpha) {
        int track = UIRenderUtil.lerpArgb(COL_OFF, COL_ACCENT, progress);
        UIRenderUtil.fillRounded(context, x, y, x + 28, y + 14, 7, withAlpha(track, globalAlpha));
        int knobX = (int) UIRenderUtil.lerp(x + 2, x + 15, progress);
        UIRenderUtil.fillRounded(context, knobX, y + 2, knobX + 11, y + 12, 5, withAlpha(0xFFFFFFFF, globalAlpha));
    }

    private static int withAlpha(int argbOpaque, float alphaMul) {
        int a = (argbOpaque >>> 24) & 0xFF;
        int newA = Math.round(a * clamp01(alphaMul));
        return (newA << 24) | (argbOpaque & 0xFFFFFF);
    }

    // ---------------------------------------------------------------- live HUD preview

    private void renderLivePreview(DrawContext context) {
        for (Module m : NSClientClient.MODULES.getModules()) {
            if (m instanceof HudModule hud && hud.isEnabled()) {
                hud.renderHud(context, 1.0f);
            }
        }
        if (draggingHud != null) {
            int w = draggingHud.getPreviewWidth();
            int h = draggingHud.getPreviewHeight();
            int x = (int) draggingHud.getX();
            int y = (int) draggingHud.getY();
            UIRenderUtil.fillRounded(context, x - 2, y - 2, x + w + 2, y + h + 2, 4, 0x33B388FF);
        }
    }

    // ---------------------------------------------------------------- input

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (handleSidebarClick(mouseX, mouseY)) return true;
        if (handlePanelClick(mouseX, mouseY)) return true;
        if (handleHudDragStart(mouseX, mouseY)) return true;
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private boolean handleSidebarClick(double mouseX, double mouseY) {
        if (mouseX < 10 || mouseX > 10 + SIDEBAR_W) return false;
        int y = 60;
        for (Category cat : Category.values()) {
            if (isInside(mouseX, mouseY, 10, y, SIDEBAR_W, ROW_H)) {
                selectedCategory = cat;
                expanded = null;
                return true;
            }
            y += ROW_H + 2;
        }
        return false;
    }

    private boolean handlePanelClick(double mouseX, double mouseY) {
        int y = PANEL_Y + 8;
        for (Module m : getVisibleModules()) {
            int toggleX = PANEL_X + PANEL_W - 40;
            if (isInside(mouseX, mouseY, toggleX, y + 5, 28, 14)) {
                m.toggle();
                return true;
            }
            if (isInside(mouseX, mouseY, PANEL_X + 6, y, PANEL_W - 12, ROW_H)) {
                expanded = (expanded == m) ? null : m;
                return true;
            }
            y += ROW_H + 2;
            if (expanded == m) {
                for (Setting<?> setting : m.getSettings()) {
                    if (setting instanceof SliderSetting slider) {
                        int barY = y + 11;
                        if (mouseY >= barY && mouseY <= barY + 4) {
                            draggingSlider = slider;
                            updateSlider(slider, mouseX);
                            return true;
                        }
                        y += SETTING_SLIDER_H;
                    } else if (setting instanceof BooleanSetting bool) {
                        int toggleX2 = PANEL_X + PANEL_W - 40;
                        if (isInside(mouseX, mouseY, toggleX2, y, 28, 12)) {
                            bool.setValue(!bool.getValue());
                            return true;
                        }
                        y += SETTING_BOOL_H;
                    } else {
                        y += SETTING_COLOR_H;
                    }
                }
                String modeLabel = modeRowLabel(m);
                if (modeLabel != null) {
                    if (isInside(mouseX, mouseY, PANEL_X + 6, y, PANEL_W - 12, SETTING_BOOL_H)) {
                        cycleMode(m);
                        return true;
                    }
                    y += SETTING_BOOL_H;
                }
                if (mouseY >= y && mouseY <= y + KEYBIND_ROW_H) {
                    bindingModule = m;
                    return true;
                }
                y += KEYBIND_ROW_H + 6;
            }
        }
        return false;
    }

    private boolean handleHudDragStart(double mouseX, double mouseY) {
        if (mouseX <= PANEL_X + PANEL_W + 10) return false;
        for (Module mod : NSClientClient.MODULES.getModules()) {
            if (mod instanceof HudModule hud && hud.isEnabled()
                    && isInside(mouseX, mouseY, hud.getX(), hud.getY(), hud.getPreviewWidth(), hud.getPreviewHeight())) {
                draggingHud = hud;
                dragOffsetX = mouseX - hud.getX();
                dragOffsetY = mouseY - hud.getY();
                return true;
            }
        }
        return false;
    }

    private void updateSlider(SliderSetting slider, double mouseX) {
        int barX = PANEL_X + 14;
        int barW = PANEL_W - 40;
        double pct = clamp01((mouseX - barX) / (double) barW);
        double raw = slider.getMin() + pct * (slider.getMax() - slider.getMin());
        double stepped = Math.round(raw / slider.getStep()) * slider.getStep();
        slider.setValue(Math.max(slider.getMin(), Math.min(slider.getMax(), stepped)));
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (draggingSlider != null) {
            updateSlider(draggingSlider, mouseX);
            return true;
        }
        if (draggingHud != null) {
            draggingHud.setX(mouseX - dragOffsetX);
            draggingHud.setY(mouseY - dragOffsetY);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        draggingSlider = null;
        draggingHud = null;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (mouseX > PANEL_X + PANEL_W + 10) {
            for (Module mod : NSClientClient.MODULES.getModules()) {
                if (mod instanceof HudModule hud && hud.isEnabled()
                        && isInside(mouseX, mouseY, hud.getX(), hud.getY(), hud.getPreviewWidth(), hud.getPreviewHeight())) {
                    hud.setScale(hud.getScale() + (verticalAmount > 0 ? 0.05 : -0.05));
                    return true;
                }
            }
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (bindingModule == null) {
            search += chr;
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (bindingModule != null) {
            bindingModule.setKeyCode(keyCode == GLFW.GLFW_KEY_ESCAPE ? -1 : keyCode);
            bindingModule = null;
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) {
            search = search.substring(0, search.length() - 1);
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private static boolean isInside(double px, double py, double x, double y, double w, double h) {
        return px >= x && px <= x + w && py >= y && py <= y + h;
    }

    private static double clamp01(double v) { return Math.max(0, Math.min(1, v)); }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void close() {
        ConfigManager.save(NSClientClient.MODULES);
        super.close();
    }
}
