package com.nsclient.module.impl;

import com.nsclient.NSClientMod;
import com.nsclient.module.Category;
import com.nsclient.module.HudModule;
import com.nsclient.module.setting.ColorSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class WatermarkHudModule extends HudModule {
    private final ColorSetting color = register(new ColorSetting("color", 0xFFB388FF));

    public WatermarkHudModule() {
        super("watermark_hud", "Watermark", "Shows the client name on screen", Category.HUD, true, 5, 5);
    }

    @Override public int getPreviewWidth() { return 90; }
    @Override public int getPreviewHeight() { return 12; }

    @Override
    public void renderHud(DrawContext context, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        context.getMatrices().push();
        context.getMatrices().translate(getX(), getY(), 0);
        context.getMatrices().scale((float) getScale(), (float) getScale(), 1f);
        context.drawTextWithShadow(mc.textRenderer, NSClientMod.MOD_NAME, 0, 0, color.getValue());
        context.getMatrices().pop();
    }
}
