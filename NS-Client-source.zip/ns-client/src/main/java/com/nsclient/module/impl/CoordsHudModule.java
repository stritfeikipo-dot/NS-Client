package com.nsclient.module.impl;

import com.nsclient.module.Category;
import com.nsclient.module.HudModule;
import com.nsclient.module.setting.ColorSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class CoordsHudModule extends HudModule {
    private final ColorSetting color = register(new ColorSetting("color", 0xFFB388FF));

    public CoordsHudModule() {
        super("coords_hud", "Coordinates", Category.HUD, true, 5, 51);
    }

    @Override public int getPreviewWidth() { return 110; }
    @Override public int getPreviewHeight() { return 10; }

    @Override
    public void renderHud(DrawContext context, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        String text = String.format("X: %.1f Y: %.1f Z: %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
        context.getMatrices().push();
        context.getMatrices().translate(getX(), getY(), 0);
        context.getMatrices().scale((float) getScale(), (float) getScale(), 1f);
        context.drawTextWithShadow(mc.textRenderer, text, 0, 0, color.getValue());
        context.getMatrices().pop();
    }
}
